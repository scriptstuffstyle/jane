// HTML���ߍ��݌^�̉摜���r���[�A�ŊJ��

// �摜�t�@�C���̃L���b�V������CreateVwCache.js�̃R�[�h���ꕔ���ς��ė��p���Ă��܂��B
// http://www31.atwiki.jp/jane_js/pages/57.html

var Requires = 1210090526;
var MyVer = "130213";
var MyName = "ImageURLEx"

var ImageViewURLReplacePath = JaneScript.ExeName().replace(/[^\\]+$/, "") + "ImageViewURLReplace.dat";
var Ini = JaneScript.GetScriptConfig();

var UrlReplaceDat = [];
var DLList = {};
var ConfigView;
var Setting;

if(Requires <= (JaneScript.GetVersionInfo().substr(1) * 1))
{
	var MenuRoot = JaneScript.InsertMenu("MainWnd.MainMenu", "MenuScript", 0);
	MenuRoot.Caption = MyName;
	
	var MenuOption = MenuRoot.Add();
	MenuOption.Caption = "�ݒ�";
	MenuOption.OnClick = MenuOptionOnClick;
	
	var MenuBrowseSite = MenuRoot.Add();
	MenuBrowseSite.Caption = "�X�N���v�g�z�z�����J��";
	MenuBrowseSite.OnClick = MenuBrowseSiteOnClick;
	
	var MenuPopupTextSelection = JaneScript.InsertMenu("MainWnd.PopupTextMenu", "", "TextPopUpOpenSelectionURLs");
	MenuPopupTextSelection.Caption = "�I��͈͂�URL��ImageURLEx�ɑ���";
	MenuPopupTextSelection.OnBeforeShow = MenuPopupTextSelectionOnBeforeShow;
	MenuPopupTextSelection.OnClick = MenuPopupTextSelectionOnClick;
	
	var MenuImagePopUp = JaneScript.InsertMenu("ImageForm.ImagePopUpMenu", "", "miReloadImage");
	MenuImagePopUp.Caption = "ImageURLEx�ōēǍ�";
	MenuImagePopUp.OnBeforeShow = MenuImagePopUpOnBeforeShow;
	MenuImagePopUp.OnClick = MenuImagePopUpOnClick;
	
	JaneScript.ExportObject("Initialize", Initialize);
	JaneScript.ExportObject("LoadDat", LoadDat);
	
	AppActionConfigured = function ()
	{
		Initialize()
	}
	
	LinkActionBrowserNavigate = function (item, url, x, y)
	{
		if(!url.indexOf("config:") && item === ConfigView)
		{
			var param = url.split(":");
			Setting[param[1]] = !!(param[2] * 1);
			
			Ini.Write(MyName, param[1], Setting[param[1]] ? 1 : 0);
			Ini.UpdateFile();
			
			ShowSetting();
			return "";
		}
		
		return OpenImage(url, 0);
	}
}
else
{
	JaneScript.Log("�G���[�F" + MyName + " �� Jane View " + Requires + " �ȍ~���K�v�ł�")
}

function MenuOptionOnClick(menuObject, targetInfo)
{
	ShowSetting();
}

function MenuBrowseSiteOnClick(menuObject, targetInfo)
{
	JaneScript.Open("http://sites.google.com/site/scriptstuffstyle/", 0, 0, false, false, false);
}

function MenuPopupTextSelectionOnBeforeShow(menuObject, targetInfo)
{
	menuObject.Visible = !!(targetInfo.PopupObject.Selection) && CheckPopupTextLinks(targetInfo.PopupObject.SelectedLinks()) && IsUseViewCache();
}

function MenuPopupTextSelectionOnClick(menuObject, targetInfo)
{
	var aview = targetInfo.PopupObject;
	var strs = aview.SelectedLinks();
	
	for(var i = 0, len = strs.Count; i < len; ++i)
	{
		if(!aview.Connected || JaneScript.Terminated)
			return;
		
		OpenImageEx(strs.Items(i), 2);
	}
	
	FocusThread(2);
	JaneScript.Log("�摜�W�J����");
}

function MenuImagePopUpOnBeforeShow(menuObject, targetInfo)
{
	try
	{
		menuObject.Visible = CheckLink(JaneScript.ImageViewer.ActivePage.SubUrl) && IsUseViewCache();
	}
	catch(e)
	{
		menuObject.Visible = false;
	}
}

function MenuImagePopUpOnClick(menuObject, targetInfo)
{
	try
	{
		var url = JaneScript.ImageViewer.ActivePage.SubUrl;
		if(!url)
			return;
		
		JaneScript.ImageViewer.DeleteCache(url);
	}
	catch(e)
	{
		return;
	}
	
	OpenImageEx(url, 4);
}

function Initialize()
{
	if(Setting)
		return;
	
	Setting = {
		MouseClick : !!(Ini.Read(MyName, "MouseClick", "0") * 1),
		MouseOver : !!(Ini.Read(MyName, "MouseOver", "0") * 1),
		SelectedLinks : !!(Ini.Read(MyName, "SelectedLinks", "0") * 1),
		OpenTwitImage : !!(Ini.Read(MyName, "OpenTwitImage", "0") * 1)
	};
	
	// ���̃I�v�V������JaneView�N�����ɔ��f�����
	if(JaneScript.GetJaneConfig().Read("IMAGE", "OpenURLOnMouseOver", "0") * 1)
	{
		LinkActionBrowserStatusTextChange = function (item, url, x, y)
		{
			return OpenImage(url, 1);
		}
	}
	
	LoadDat();
}

function IsUseViewCache()
{
	return !!(JaneScript.GetImageViewConfig().Read("Cache", "UseViewCache", "1") * 1);
}

function LoadDat()
{
	try
	{
		var dat = new ActiveXObject("Scripting.FileSystemObject").OpenTextFile(ImageViewURLReplacePath, 1);
		var datArr = dat.ReadAll().split("\r\n");
		dat.Close();
	}
	catch(e)
	{
		JaneScript.Log(e.message);
		return;
	}
	
	var replaceDat = [];
	
	for(var i = 0; i < datArr.length; ++i)
	{
		var datLine = datArr[i].split("\t");
		if(4 < datLine.length)
		{
			if(0 <= datLine[3].indexOf("$EXTRACACHE"))
				replaceDat.push([new RegExp(datLine[0]), new RegExp(datLine[4]), (5 < datLine.length) ? datLine[5] : "$1"]);
		}
	}
	
	UrlReplaceDat = replaceDat;
}

function CheckLink(str)
{
	return (!str.indexOf("http:") || !str.indexOf("https:")) && (str.indexOf("/read.cgi/") < 0);
}

function CheckPopupTextLinks(strs)
{
	for(var i = 0, len = strs.Count; i < len; ++i)
	{
		if(CheckLink(strs.Items(i)))
			return true;
	}
	
	return false;
}

function OpenImage(url, caller)
{
	if(!IsUseViewCache() || JaneScript.ImageViewUrlReplace(url).Action !== "EXTRACACHE")
		return;
	
	var dat = UrlReplaceDat
	
	for(var i = 0, len = dat.length; i < len; ++i)
	{
		if(dat[i][0].test(url))
		{
			if(GetImage(url, dat[i], caller))
				return url;
			else
				return "";
		}
	}
}

function OpenImageEx(url, caller)
{
	var res = OpenImage(url, caller);
	if(typeof res !== "undefined")
	{
		if(res)
			JaneScript.Open(url, 1, 3, true, false, false);
	}
	else
	{
		var ret = JaneScript.ImageViewUrlReplace(url);
		if(ret.Action === "VIEWER" || ((ret.Action === "VIEWNOIMAGE" || ret.Action === "NONE") && JaneScript.IsImageURL(ret.Url)))
			JaneScript.Open(url, 1, 3, true, false, false);
	}
}

function GetImage(inUrl, urlReplaceDatLine, caller)
{
 	try
 	{
		function AlreadyDownloadingError()
		{
			this.message = "���̉摜�̓_�E�����[�h���ł�";
		}
		
		function DLListPush(url)
		{
			if(url in DLList)
				throw new AlreadyDownloadingError();
			else
				DLList[url] = null;
		}
		
		function DLListPop(url)
		{
			delete DLList[url];
		}
		
		function isEmpty(hash)
		{
			for(var i in hash)
				return false;
			
			return true;
		}
		
		var ret = JaneScript.ImageViewUrlReplace(inUrl);
		var txturl = ret.Url;
		
		if(JaneScript.ImageViewer.CacheExists(txturl))
			return (caller !== 3);
		
		JaneScript.Log(txturl);
		
		DLListPush(txturl);
		
		if(1 < caller)
			FocusThread(caller);
		
		var useAsync = (caller !== 3);
		var hrqTxt = SendRequest(txturl, txturl, true, useAsync);
		
		if(caller < 2)
			FocusThread(caller);
		
		if(!hrqTxt)
			throw Error("�摜�y�[�W�̎擾�Ɏ��s���܂���");
		
		var ma = hrqTxt.responseText.match(urlReplaceDatLine[1]);
		if(ma)
		{
			var imgUrl = JaneScript.CombineUrl(txturl, ma[0].replace(urlReplaceDatLine[1], urlReplaceDatLine[2]));
			JaneScript.Log("�摜�擾�F" + imgUrl);
			var hrqImg = SendRequest(imgUrl, txturl, false, useAsync);
			if(caller < 2)
				FocusThread(caller);
			
			if(!hrqImg)
				throw Error("�摜�̎擾�Ɏ��s���܂���");
			
			CreateImageCache(txturl, hrqImg);
		}
		else if(0 <= hrqTxt.responseText.indexOf("<"))
		{
			JaneScript.Log("�摜URL��������܂���ł���");
			CreateImageCache(txturl, hrqTxt);
		}
		else
			throw Error("�摜�y�[�W�̎擾�Ɏ��s���܂���");
		
		DLListPop(txturl);
		
		if(isEmpty(DLList))
			JaneScript.LateCall(FocusThread, caller);
		
		return true;
 	}
 	catch(e)
 	{
		if(!(e instanceof AlreadyDownloadingError))
			DLListPop(txturl);
		
		JaneScript.Log(e.message);
		return false;
	}
}

function SendRequest(url, referer, gettext, useAsync)
{
	try
	{
		var hrq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
		hrq.open("GET", url, true);
		hrq.setRequestHeader("Referer", referer);
		var viewCfg = JaneScript.GetImageViewConfig();
		var ua = viewCfg.Read("HTTP", "CustomUserAgent", "");
		hrq.setRequestHeader("User-Agent", ua ? ua : "JaneViewViewer/" + JaneScript.GetVersionInfo().substr(1));
		hrq.send();
		
		var timeout = gettext ? 10000 : (viewCfg.Read("HTTP", "TimeOut", "30000") * 1);
		
		if(useAsync)
		{
			var start = new Date();
			while(!hrq.waitForResponse(0))
			{
				JaneScript.HandleMessage();
				
				if(timeout < new Date() - start)
					throw Error("�ڑ��^�C���A�E�g");
				
				if(JaneScript.Terminated)
					throw Error("");
			}
		}
		else
		{
			if(!hrq.waitForResponse(timeout))
				throw Error("�ڑ��^�C���A�E�g");
		}
		
		if(hrq.status !== 200)
			throw Error(hrq.status + " " + hrq.statusText);
		
		return hrq;
	}
	catch(e)
	{
		JaneScript.Log(e.message);
		return null;
	}
}

function FocusThread(caller)
{
	try
	{
		function check(i)
		{	
			switch(caller)
			{
			case 0:
				return Setting.MouseClick;
			case 1:
				return Setting.MouseOver;
			case 2:
				return Setting.SelectedLinks;
			case 3:
				return Setting.OpenTwitImage;
			}
			
			return false;
		}
		
		if(check(caller))
			JaneScript.ExecuteMenu("MainWnd.MainMenu", "MenuWndThread");
		
		JaneScript.ProcessMessages();
	}
	catch(e){}
}

function ShowSetting()
{
	function html()
	{
		function makeStr(label, name)
		{
			return "<dt>" + label + "</dt><dd>���݂̐ݒ�F" + (Setting[name] ? "<b>�L��</b>" : "����")
				+ '�@�@<a href="config:' + name + (!Setting[name] ? ':1">�L��' : ':0">����') + "�ɂ���</a><br><br></dd>";
		}
		
		return "���r���[�A��A�N�e�B�u���̐ݒ�<br><br>"
			+ makeStr("�}�E�X�N���b�N", "MouseClick")
			+ makeStr("�}�E�X�I�[�o�[", "MouseOver")
			+ makeStr("�I��͈͂�ImageURLEx�ɑ���", "SelectedLinks")
			+ (function(){try{JaneScript.ImportObject("Twitter.js");}catch(e){return false;}return true;}() ?
				makeStr("Twitter�擾���̎����W�J", "OpenTwitImage") : "")
			+ "</dl>";
	}
	
	if(ConfigView && ConfigView.Connected)
		ConfigView.Clear();
	else
	{
		ConfigView = JaneScript.ViewList.NewView(false, false);
		ConfigView.TabText = ConfigView.ExtraTitle = "ImageURLEx�̐ݒ�";
	}
	
	try
	{
		var dout = ConfigView.QueryDatOut();
		ConfigView.WriteSkin("");
		dout.WriteHTML(html());
	}
	catch(e)
	{
		if((e.number & 0xFFFF) !== 0x8001)
			throw e;
	}
	finally
	{
		if(ConfigView.Connected)
			ConfigView.EndDatOut();
		
		try
		{
			ConfigView.Activate();
		}
		catch(e){}
	}
}

// �ȉ�CreateVwCache.js��藬�p�@���ϗL

// �摜�L���b�V���쐬 ���������΍�
function CreateImageCache(url, hrq)
{
	var rcont = hrq.getResponseHeader("Content-Type");
	// Content-Type�̃`�F�b�N
	if(rcont && (rcont.indexOf("image") < 0) && (rcont.indexOf("octet-stream") < 0) && (rcont.indexOf("x-www-form") < 0) && (rcont.indexOf("text") < 0))
	{
		JaneScript.Log("Content-Type���s���ł� : " + rcont);
		return;
	}
	
	try
	{
		var rdate = hrq.getResponseHeader("Last-Modified");
	}
	catch(e)
	{
		rdate = new Date().toUTCString().replace("UTC", "GMT");
	}
	
	var i, tmp;
	var header = ((JaneScript.GetImageViewConfig().Read("General", "AlwaysProtect", "0") * 1) ? "STATUS=PROTECT\r\n" : "")
		+ "ContentType=" + rcont + "\r\nLastModified=" + rdate + "\r\nRESCODE=-1\r\nURL=" + url + "\r\n";
	var headerlen = header.length;
	var adstream = new ActiveXObject("ADODB.Stream");
	var adstream2 = new ActiveXObject("ADODB.Stream");
	var adstream3 = new ActiveXObject("ADODB.Stream");
	adstream2.Type = 2;
	adstream2.Charset = "UNICODE";
	adstream2.Open();
	for(i=0; i<4; i++)
	{
		if((tmp = ((headerlen >>> 8*i) & 0xff)) > 0)
		{
			adstream2.WriteText(String.fromCharCode(tmp));
		}
		else{adstream2.WriteText(String.fromCharCode(0x0));}
	}
	adstream3.Type = 2;
	adstream3.CharSet = "Shift_JIS";
	adstream3.Open();
	adstream3.WriteText(header);
	adstream2.Position = 0;
	adstream3.Position = 0;
	adstream2.Type = 1;
	adstream3.Type = 1;
	adstream.Type = 1;
	adstream.Open();
	adstream2.Read(2);
	for(i=0; i<4; i++)
	{
		adstream.Write(adstream2.Read(1));
		adstream2.Read(1);
	}
	adstream2.Close();
	adstream.Write(adstream3.Read());
	adstream3.Close();
	adstream.Write(hrq.responseBody);
	adstream.SaveToFile(JaneScript.ImageViewer.GetCacheFileName(url, true), 1 && 2);
	adstream.Close();
}

// ------------------------------------------
// compatibility......

if(Requires <= (JaneScript.GetVersionInfo().substr(1) * 1))
{
	// Twitter�W�J���ɉ摜�擾
	JaneScript.ExportObject("OpenTwitImage", function (strs)
	{
		var aview = JaneScript.ActiveView();
		
		for(var i = 0, len = strs.Count; i < len; ++i)
		{
			if(!aview.Connected || JaneScript.Terminated)
				return;
			
			var url = strs.Items(i);
			
			var res = OpenImage(url, 3);
			if(typeof res !== "undefined")
			{
				if(res)
					JaneScript.Open(url, 1, 3, true, false, false);
			}
			else
			{
				var ret = JaneScript.ImageViewUrlReplace(url);
				if(ret.Action === "VIEWER" || ((ret.Action === "VIEWNOIMAGE" || ret.Action === "NONE") && JaneScript.IsImageURL(ret.Url)))
				{
					if(!JaneScript.ImageViewer.CacheExists(ret.Url))
						JaneScript.Open(url, 1, 3, true, false, false);
				}
			}
		}
		
		FocusThread(3);
		JaneScript.Log("�摜�W�J����");
	});
	
	JaneScript.ExportObject("GetCachePath", function (url)
	{
		JaneScript.Log("'GetCachePath' is deprecated. Use 'ImageViewer.GetCacheFileName' instead.")
		return JaneScript.ImageViewer.GetCacheFileName(url, true);
	});
}
