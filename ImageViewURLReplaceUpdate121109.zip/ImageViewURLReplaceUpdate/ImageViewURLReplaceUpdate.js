// ImageViewURLReplace.dat���X�V����

var MyVer = "121109";
var ImageViewURLReplacePath = JaneScript.ExeName().replace(/[^\\]+$/, "") + "ImageViewURLReplace.dat";
var JaneScriptPath = JaneScript.ExeName().replace(/[^\\]+$/, "") + "Script\\";
var ImageViewURLReplaceUpdateUrl = "http://sites.google.com/site/scriptstuffstyle/download/ImageViewURLReplace.dat";
var Ini = JaneScript.GetScriptConfig();

var MenuRoot = JaneScript.InsertMenu("MainWnd.MainMenu", "MenuScript", 0);
MenuRoot.Caption = "ImageViewURLReplaceUpdate";

var MenuOption = MenuRoot.Add();
MenuOption.Caption = "�ݒ�";

var MenuOptionAutoUpdate = MenuOption.Add();
MenuOptionAutoUpdate.Caption = "�����X�V��L���ɂ���";
MenuOptionAutoUpdate.Checked = Ini.Read("ImageViewURLReplace.dat", "EnableAutoUpdate", "0") * 1;
MenuOptionAutoUpdate.OnClick = MenuOptionAutoUpdateOnClick;

var MenuOptionImageURLEx = MenuOption.Add();
MenuOptionImageURLEx.Caption = "ImageURLEx�p�̋L�q����荞��";
MenuOptionImageURLEx.Checked = Ini.Read("ImageViewURLReplace.dat", "EnableImageURLEx", "0") * 1;
MenuOptionImageURLEx.OnClick = MenuOptionImageURLExClick;

var MenuEditUserFile = MenuRoot.Add();
MenuEditUserFile.Caption = "���[�U�[��`�p�t�@�C���ҏW";

var MenuEditUserFileHead = MenuEditUserFile.Add();
MenuEditUserFileHead.Caption = "ImageViewURLReplaceUpdate.head";
MenuEditUserFileHead.OnClick = MenuEditUserFileHeadOnClick;

var MenuEditUserFileFoot = MenuEditUserFile.Add();
MenuEditUserFileFoot.Caption = "ImageViewURLReplaceUpdate.foot";
MenuEditUserFileFoot.OnClick = MenuEditUserFileFootOnClick;

var MenuManualUpdate = MenuRoot.Add();
MenuManualUpdate.Caption = "�蓮�X�V";
MenuManualUpdate.OnClick = MenuManualUpdateOnClick;

var MenuBrowseSite = MenuRoot.Add();
MenuBrowseSite.Caption = "�X�N���v�g�z�z�����J��";
MenuBrowseSite.OnClick = MenuBrowseSiteOnClick;

var LoadDat;

function AppActionConfigured()
{
	try{
		var obj = JaneScript.ImportObject("ImageURLEx.js");
		try{
			obj.Initialize();
		}catch(e){}
		
		LoadDat = obj.LoadDat;
	}catch(e){}
	
	if(new Date().getTime() - Ini.Read("ImageViewURLReplace.dat", "LastTime", "0") * 1 < 0x2932e00)
		return;
	
	HttpRequest("ImageViewURLReplace.dat");
}

function MenuOptionAutoUpdateOnClick(menuObject, targetInfo)
{
	MenuOptionAutoUpdate.Checked = !MenuOptionAutoUpdate.Checked;
	
	Ini.Write("ImageViewURLReplace.dat", "EnableAutoUpdate", MenuOptionAutoUpdate.Checked ? 1 : 0 );
	Ini.UpdateFile()
}

function MenuOptionImageURLExClick(menuObject, targetInfo)
{
	MenuOptionImageURLEx.Checked = !MenuOptionImageURLEx.Checked;
	
	Ini.Write("ImageViewURLReplace.dat", "EnableImageURLEx", MenuOptionImageURLEx.Checked ? 1 : 0 );
	Ini.UpdateFile()
}

function MenuEditUserFileHeadOnClick(menuObject, targetInfo)
{
	OpenEditor(JaneScriptPath + "ImageViewURLReplaceUpdate.head");
}

function MenuEditUserFileFootOnClick(menuObject, targetInfo)
{
	OpenEditor(JaneScriptPath + "ImageViewURLReplaceUpdate.foot");
}

function MenuManualUpdateOnClick(menuObject, targetInfo)
{
	if(HttpRequest("ImageViewURLReplace.dat"))
	{
		JaneScript.ExecuteMenu("MainWnd.MainMenu", "MenuImageViewPreference");
		if(LoadDat)
			LoadDat();
	}
}

function MenuBrowseSiteOnClick(menuObject, targetInfo)
{
	JaneScript.Open("http://sites.google.com/site/scriptstuffstyle/", 0, 0, false, false, false);
}

function ReadText(source)
{
	try
	{
		var srcStream = new ActiveXObject("ADODB.Stream");
		srcStream.Type = 1;
		srcStream.Open();
		srcStream.Write(source);
		srcStream.Position = 0;
		srcStream.Type = 2;
		srcStream.Charset = "Shift_JIS";
		
		var dstStream = new ActiveXObject("ADODB.Stream");
		dstStream.Open();
		
		srcStream.CopyTo(dstStream);
		srcStream.Close();
		
		dstStream.Position = 0;
		return dstStream.ReadText();
	}
	catch(e)
	{
		return "";
	}
}

function HttpRequest(filename)
{
	try
	{
		JaneScript.Log(filename + " �X�V�J�n");
		
		var httpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
		var dat = "";
		
		try
		{
			httpReq.open("GET", ImageViewURLReplaceUpdateUrl);
			httpReq.setRequestHeader("User-Agent", "ImageViewURLReplaceUpdate.js/" + MyVer + "(" + JaneScript.GetVersionInfo() + ")");
			httpReq.send();
			
			if(httpReq.status !== 200)
			{
				JaneScript.Log(filename + " �X�V���s:101");
				return false;
			}
			
			dat += ReadText(httpReq.responseBody);
		}
		catch(e)
		{
			JaneScript.Log(filename + " �X�V���s:100");
			return false;
		}
		
		if(MenuOptionImageURLEx.Checked)
		{
			dat += "\r\n";
			
			try
			{
				httpReq.open("GET", ImageViewURLReplaceUpdateUrl + ".ImageURLEx" + (!!LoadDat ? "2" : ""));
				httpReq.send();
				
				if(httpReq.status !== 200)
				{
					JaneScript.Log(filename + " �X�V���s:201");
					return false;
				}
				
				dat += ReadText(httpReq.responseBody);
			}
			catch(e)
			{
				JaneScript.Log(filename + " �X�V���s:200");
				return false;
			}
		}
		
		SaveImageViewURLReplacePathDat(filename, dat);
	}
	catch(e)
	{
		JaneScript.Log(filename + " �X�V���s:000");
		return false;
	}
	
	return true;
}

function SaveImageViewURLReplacePathDat(filename, text)
{
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var dat = fso.CreateTextFile(ImageViewURLReplacePath, true);
	
	var header = "\r\n> ImageViewURLReplaceUpdate.js���g�p���Ă���ꍇImageViewURLReplace.dat�𒼐ڕҏW���Ă�����X�V���ɏ㏑������܂�\r\n> Script�t�H���_����ImageViewURLReplaceUpdate.head��ImageViewURLReplaceUpdate.foot���g�p���Ă�������\r\n> �܂�������ImageViewURLReplaceUpdate.js�ɂ��X�V���s����܂Ŕ��f����Ȃ����Ƃɒ��ӂ��Ă�������\r\n\r\n";
	
	try
	{
		var subDat = fso.OpenTextFile(JaneScriptPath + "ImageViewURLReplaceUpdate.head", 1);
		var tmp = subDat.ReadAll();
		
		if(tmp.substring(0, 2) === "<$")
		{
			var reg = /^((?:<\$\w+>)*)([\s\S]*)$/;
			var tmpArr = tmp.match(reg);
			var txtArr = text.match(reg);
			
			tmp = tmpArr[2];
			text = tmpArr[1] + "\r\n" + txtArr[2];
		}
		
		header += tmp;
	}
	catch(e){}
	
	text += "\r\n";
	
	dat.WriteLine(text.replace("\r\n", header));
	
	try
	{
		var subDat = fso.OpenTextFile(JaneScriptPath + "ImageViewURLReplaceUpdate.foot", 1);
		dat.WriteLine(subDat.ReadAll());
	}
	catch(e){}
	
	dat.Close();
	
	JaneScript.Log(filename + " �X�V����");
	
	Ini.Write(filename, "LastTime", new Date().getTime());
	Ini.UpdateFile()
}

function OpenEditor(targetPath)
{
	var editorPath = JaneScript.GetJaneConfig.Read("EXTERNAL", "EditorPath", "");
	if(editorPath)
	{
		var tmp = editorPath.match(/^("[\s\S]*\.exe"|[\s\S]*\.exe)([\s\S]*)$/i);
		
		targetPath = "\"" + targetPath.replace(/\$/g, "\\\$") + "\"";
		targetPath = tmp[2].replace(/\$(LINE|COLUMN)/g, "1").replace(/\$FILE/g, targetPath);
		
		JaneScript.ShellExecute(tmp[1], targetPath, "");
	}
	else
	{
		JaneScript.ShellExecute(targetPath, "", "");
	}
}

