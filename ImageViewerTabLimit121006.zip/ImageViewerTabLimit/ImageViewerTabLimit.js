// �r���[�A�̃^�u������萔�ȉ��ɐ���

var MyVer = "121006";
var MyName = "ImageViewerTabLimit"
var Ini = JaneScript.GetScriptConfig();

var MenuRoot = JaneScript.InsertMenu("MainWnd.MainMenu", "MenuScript", 0);
MenuRoot.Caption = MyName;

var MenuOption = MenuRoot.Add();
MenuOption.Caption = "�ݒ�";

var MenuOptionLimitTypeDefault = MenuOption.Add();
MenuOptionLimitTypeDefault.Caption = "�f�t�H���g";
MenuOptionLimitTypeDefault.Checked = GetLimitType() == -1;
MenuOptionLimitTypeDefault.OnClick = MenuOptionLimitTypeDefaultOnClick;

var MenuOptionLimitType0 = MenuOption.Add();
MenuOptionLimitType0.Caption = "���ׂĕ���";
MenuOptionLimitType0.Checked = GetLimitType() == 0;
MenuOptionLimitType0.OnClick = MenuOptionLimitType0OnClick;

var MenuOptionLimitType1 = MenuOption.Add();
MenuOptionLimitType1.Caption = "1�ɐ���";
MenuOptionLimitType1.Checked = GetLimitType() == 1;
MenuOptionLimitType1.OnClick = MenuOptionLimitType1OnClick;

var MenuOptionLimitType50 = MenuOption.Add();
MenuOptionLimitType50.Caption = "50�ɐ���";
MenuOptionLimitType50.Checked = GetLimitType() == 2;
MenuOptionLimitType50.OnClick = MenuOptionLimitType50OnClick;

var MenuOptionLimitType100 = MenuOption.Add();
MenuOptionLimitType100.Caption = "100�ɐ���";
MenuOptionLimitType100.Checked = GetLimitType() == 3;
MenuOptionLimitType100.OnClick = MenuOptionLimitType100OnClick;

var MenuOptionLimitType200 = MenuOption.Add();
MenuOptionLimitType200.Caption = "200�ɐ���";
MenuOptionLimitType200.Checked = GetLimitType() == 4;
MenuOptionLimitType200.OnClick = MenuOptionLimitType200OnClick;

var MenuBrowseSite = MenuRoot.Add();
MenuBrowseSite.Caption = "�X�N���v�g�z�z�����J��";
MenuBrowseSite.OnClick = MenuBrowseSiteOnClick;

function ViewerActionImageTabCompleted(imageTab)
{
	JaneScript.LateCall(AutoClose, null);
}

function MenuOptionLimitTypeDefaultOnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(-1);
}

function MenuOptionLimitType0OnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(0);
}

function MenuOptionLimitType1OnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(1);
}

function MenuOptionLimitType50OnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(2);
}

function MenuOptionLimitType100OnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(3);
}

function MenuOptionLimitType200OnClick(menuObject, targetInfo)
{
	MenuOptionLimitTypeSet(4);
}

function MenuBrowseSiteOnClick(menuObject, targetInfo)
{
	JaneScript.Open("http://sites.google.com/site/scriptstuffstyle/", 0, 0, false, false, false);
}

function GetLimitType()
{
	var type = Ini.Read(MyName, "LimitType", "-1") * 1;
	if(type < 0 || 4 < type)
		type = -1;
	
	return type;
}

function GetLimit(type)
{
	switch(type)
	{
	case 0:
		return 0;
	case 1:
		return 1;
	case 2:
		return 50;
	case 3:
		return 100;
	case 4:
		return 200;
	}

	return JaneScript.GetJaneConfig().Read("IMAGE", "OpenNewImagesUntil", "100") * 1;
}

function MenuOptionLimitTypeSet(type)
{
	Ini.Write(MyName, "LimitType", type);
	Ini.UpdateFile()
	
	MenuOptionLimitTypeDefault.Checked = (type == -1);
	MenuOptionLimitType0.Checked = (type == 0);
	MenuOptionLimitType1.Checked = (type == 1);
	MenuOptionLimitType50.Checked = (type == 2);
	MenuOptionLimitType100.Checked = (type == 3);
	MenuOptionLimitType200.Checked = (type == 4);
	
	AutoClose(null);
}

function AutoClose(obj)
{
	var iv = JaneScript.ImageViewer;
	var type = GetLimitType();
	var limit = GetLimit(type);
	var isAll = type == 0;

	for(var n = iv.PageCount - limit; 0 < n; --n)
	{
		var flag = false;
		for(var i = 0; i < iv.PageCount - limit + (!isAll && (iv.ActivePageIndex != iv.PageCount - 1) ? 1 : 0); ++i)
		{
			var tab = iv.Pages(i);
			if(5 < tab.GetStatus() &&  (isAll || i != iv.ActivePageIndex))
			{
				tab.Close();
				flag = true;
				break;
			}
		}
		
		if(!flag)
			break;
	}
}

